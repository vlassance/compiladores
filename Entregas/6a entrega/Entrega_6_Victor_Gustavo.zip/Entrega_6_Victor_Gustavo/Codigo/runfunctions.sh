. ./mvnfunctions.sh 

makelib ./std.asm 
makelib ./stdio.asm 
makemain ./ENTRADA.asm 


