Este pacote possui o compilador de uma linguagem simples, baseada em C:

Compilar:

    $ make clean
    $ make 

    deve deletar arquivos antigos e compilar o projeto, rodando os testes em cima
    do arquivo ./ENTRADA.txt 

Testar com valgrind:
    $ make clean  
    $ make valgrind

Versões de software:

    $  gcc --version
    gcc (GCC) 4.8.1 20130725 (prerelease)
    Copyright (C) 2013 Free Software Foundation, Inc.
    This is free software; see the source for copying conditions.  There is NO
    warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    
    $  make --version
    GNU Make 3.82
    Built for x86_64-unknown-linux-gnu
    Copyright (C) 2010  Free Software Foundation, Inc.
    License GPLv3+: GNU GPL version 3 or later
    <http://gnu.org/licenses/gpl.html>
    This is free software: you are free to change and redistribute it.
    There is NO WARRANTY, to the extent permitted by law.

