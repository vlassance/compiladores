#!/bin/bash

SCRIPTPATH=`pwd -P`
java -jar Automatic_JAR_images.jar "$SCRIPTPATH/"
